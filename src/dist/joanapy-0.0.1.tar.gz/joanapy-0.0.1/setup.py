from setuptools import find_packages, setup

setup(
    name='joanapy',
    version="0.0.1",
    author="Andreas Kopf",
    author_email="akopfethz@gmail.com",
    description="Joint multi-level Ontology enrichment ANAlysis",
    install_requires=[],
    classifiers=[
        'Programming Language :: Python :: 3'
    ],
    packages=find_packages(),  # will return a list ['spam', 'spam.fizz']
    include_package_data=True,
    # package_data={'Infer.Compiler.dll': ['joanapy/joana_app/Infer.Compiler.dll'],
    #               'Infer.Compiler.pdb': ['joanapy/joana_app/Infer.Compiler.pdb'],
    #               'Infer.Compiler.xml': ['joanapy/joana_app/Infer.Compiler.xml'],
    #               'Infer.FSharp.dll': ['joanapy/joana_app/Infer.FSharp.dll'],
    #               'Infer.FSharp.pdb': ['joanapy/joana_app/Infer.FSharp.pdb'],
    #               'Infer.FSharp.xml': ['joanapy/joana_app/Infer.FSharp.xml'],
    #               'Infer.Fun.dll': ['joanapy/joana_app/Infer.Fun.dll'],
    #               'Infer.Fun.pdb': ['joanapy/joana_app/Infer.Fun.pdb'],
    #               'Infer.Fun.xml': ['joanapy/joana_app/Infer.Fun.xml'],
    #               'Infer.Runtime.dll': ['joanapy/joana_app/Infer.Runtime.dll'],
    #               'Infer.Runtime.pdb': ['joanapy/joana_app/Infer.Runtime.pdb'],
    #               'Infer.Runtime.xml': ['joanapy/joana_app/Infer.Runtime.xml'],
    #               'MathNet.Numerics.dll': ['joanapy/joana_app/MathNet.Numerics.dll'],
    #               'MonaConsoleApp.exe': ['joanapy/joana_app/MonaConsoleApp.exe'],
    #               'MonaConsoleApp.exe.config': ['joanapy/joana_app/MonaConsoleApp.exe.config'],
    #               'MonaConsoleApp.pdb': ['joanapy/joana_app/MonaConsoleApp.pdb']}
    package_data={'' : ['joanapy/joana_app/*']}
)